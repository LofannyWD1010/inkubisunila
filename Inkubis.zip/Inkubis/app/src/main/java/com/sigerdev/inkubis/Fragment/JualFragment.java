package com.sigerdev.inkubis.Fragment;


import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.sigerdev.inkubis.AturLokasiTokoActivity;
import com.sigerdev.inkubis.MainActivity;
import com.sigerdev.inkubis.OngkirActivity;
import com.sigerdev.inkubis.ProdukSayaActivity;
import com.sigerdev.inkubis.R;
import com.sigerdev.inkubis.RequestMitraActivity;
import com.sigerdev.inkubis.SharedPrefManager;
import com.sigerdev.inkubis.TambahProdukActivity;

/**
 * A simple {@link Fragment} subclass.
 */
public class JualFragment extends Fragment {

    LinearLayout llTambahProduk, llProduk, llPusatBantuan;

    public JualFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_jual, container, false);
        llTambahProduk = (LinearLayout) view.findViewById(R.id.ll_tambah_produk);
        llProduk = (LinearLayout) view.findViewById(R.id.ll_produk);
        llPusatBantuan = (LinearLayout) view.findViewById(R.id.ll_pusat_bantuan);


        llProduk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(SharedPrefManager.getInstance(getContext()).getPengguna().getStatusPengguna() == 0){
                    startActivity(new Intent(getContext(), RequestMitraActivity.class));
                }else{
                    startActivity(new Intent(getContext(), ProdukSayaActivity.class));
                }
            }
        });

        llTambahProduk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(SharedPrefManager.getInstance(getContext()).getPengguna().getStatusPengguna() == 0){
                    startActivity(new Intent(getContext(), RequestMitraActivity.class));
                }else{
                    startActivity(new Intent(getContext(), TambahProdukActivity.class));
                }
            }
        });

        llPusatBantuan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ((MainActivity)getActivity()).bukaBantuan();
            }
        });

        return view;
    }

}
