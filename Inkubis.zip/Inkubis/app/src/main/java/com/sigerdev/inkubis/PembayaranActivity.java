package com.sigerdev.inkubis;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import static android.os.Environment.getExternalStoragePublicDirectory;

import com.sigerdev.inkubis.Service.UploadBuktiService;

public class PembayaranActivity extends AppCompatActivity {

    Button btnUploadBukti, btnAmbilUlang, btnUpload;
    LinearLayout llBukti;
    ImageView ivBukti;
    TextView tvStatusProses, tvTotalBayar;
    ProgressDialog mProgressDialog;

    String pathToFile, name, nameFinal;
    Bitmap bitmapSaya;
    String kodePesanan;
    private static final int CAMERA_REQUEST = 1888;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pembayaran);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Detail Pembayaran");

        btnUploadBukti = (Button) findViewById(R.id.btn_upload_bukti);
        ivBukti = (ImageView) findViewById(R.id.iv_bukti);
        llBukti = (LinearLayout) findViewById(R.id.ll_bukti);
        btnAmbilUlang = (Button) findViewById(R.id.btn_ambil_ulang);
        btnUpload = (Button) findViewById(R.id.btn_konfirmasi_bukti);
        tvStatusProses = (TextView) findViewById(R.id.tv_status_proses);
        tvTotalBayar = (TextView) findViewById(R.id.tv_total_bayar);

        name = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());

        Intent intent = getIntent();
        kodePesanan = intent.getStringExtra("KODE_PESANAN");
        DecimalFormat formatter1 = new DecimalFormat("#,###,###");
        String yourFormattedString1 = formatter1.format(intent.getIntExtra("BAYAR", 0));
        yourFormattedString1 = yourFormattedString1.replace(",", ".");
        tvTotalBayar.setText("Rp. " + yourFormattedString1);

        llBukti.setVisibility(View.GONE);
        ivBukti.setVisibility(View.GONE);

        btnUploadBukti.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
//                startActivityForResult(cameraIntent, CAMERA_REQUEST);
                dispatchPictureTakerAction();
            }
        });

        btnAmbilUlang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
//                startActivityForResult(cameraIntent, CAMERA_REQUEST);
                dispatchPictureTakerAction();
            }
        });

        btnUpload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(bitmapSaya == null){
                    Toast.makeText(PembayaranActivity.this, "Harap Tambah Foto Bukti", Toast.LENGTH_SHORT).show();
                }else {
                    mProgressDialog = new ProgressDialog(PembayaranActivity.this);
                    mProgressDialog.setMessage("Mengupload Bukti (Sekitar 5 Detik) ...");
                    mProgressDialog.show();

                    Intent intent = new Intent(PembayaranActivity.this, UploadBuktiService.class);
                    intent.putExtra("ID_PENGGUNA", SharedPrefManager.getInstance(PembayaranActivity.this).getPengguna().getIdPengguna());
                    intent.putExtra("NAMA_FOTO", nameFinal);
                    intent.putExtra("KODE_PESANAN", kodePesanan);
                    startService(intent);



                    final Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            mProgressDialog.dismiss();
                            Intent intent = new Intent(getApplicationContext(),MainActivity.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            startActivity(intent);
                            finish();
                        }
                    }, 5000);
                }
            }
        });
    }

    public void dispatchPictureTakerAction(){
        Intent takePic = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if(takePic.resolveActivity(getPackageManager()) != null){
            File photoFile = null;
            photoFile = createPhotoFile();
            nameFinal = photoFile.getName();

            if(photoFile != null){
                pathToFile = photoFile.getAbsolutePath();
                Uri photoUri = FileProvider.getUriForFile(PembayaranActivity.this, "com.sigerdev.inkubis.fileprovider", photoFile);
                takePic.putExtra(MediaStore.EXTRA_OUTPUT, photoUri);
                startActivityForResult(takePic, 1);
            }
        }
    }

    public File createPhotoFile(){

        File storageDir = getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
        File image = null;
        try{
            image = File.createTempFile(name, ".jpeg", storageDir);
        }catch (IOException e){

        }
        return image;
    }

    public byte[] getFileDataFromDrawable(Bitmap bitmap) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
        return byteArrayOutputStream.toByteArray();
    }
    
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
//        if (requestCode == CAMERA_REQUEST && resultCode == Activity.RESULT_OK) {
//            Bitmap photo = (Bitmap) data.getExtras().get("data");
//            bitmapSaya = photo;
//            ivBukti.setImageBitmap(photo);
//            ivBukti.setVisibility(View.VISIBLE);
//            btnUploadBukti.setVisibility(View.GONE);
//            llBukti.setVisibility(View.VISIBLE);
//        }
        if(resultCode == RESULT_OK){
            if(requestCode == 1){
                Bitmap bitmap = BitmapFactory.decodeFile(pathToFile);
                ivBukti.setImageBitmap(bitmap);
                ivBukti.setVisibility(View.VISIBLE);
                bitmapSaya = bitmap;
                btnUploadBukti.setVisibility(View.GONE);
                llBukti.setVisibility(View.VISIBLE);
            }
        }
    }

    @Override
    public void onBackPressed() {
        AlertDialog.Builder builder1 = new AlertDialog.Builder(PembayaranActivity.this);
        builder1.setMessage("Anda harus menyelesaikan pembayaran pesanan ini, detail pembayaran anda terdapat pada menu pesanan");
        builder1.setCancelable(true);

        builder1.setPositiveButton(
                "Oke",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        Intent intent = new Intent(getApplicationContext(),MainActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);

                        finish();
                    }
                });

        AlertDialog alert11 = builder1.create();
        alert11.show();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home :
                AlertDialog.Builder builder1 = new AlertDialog.Builder(PembayaranActivity.this);
                builder1.setMessage("Anda harus menyelesaikan pembayaran pesanan ini, detail pembayaran anda terdapat pada menu pesanan");
                builder1.setCancelable(true);

                builder1.setPositiveButton(
                        "Oke",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                Intent intent = new Intent(getApplicationContext(),MainActivity.class);
                                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                startActivity(intent);

                                finish();
                            }
                        });

                AlertDialog alert11 = builder1.create();
                alert11.show();
                return  true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
