package com.sigerdev.inkubis.Fragment;


import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.CardView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.sigerdev.inkubis.BuildConfig;
import com.sigerdev.inkubis.R;
import com.sigerdev.inkubis.WebActivity;

/**
 * A simple {@link Fragment} subclass.
 */
public class BantuanFragment extends Fragment {

    CardView cvBeli, cvPesanan, cvKonsultasi, cvAdmin;

    public BantuanFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_bantuan, container, false);
        cvBeli = (CardView) view.findViewById(R.id.cv_beli);
        cvPesanan = (CardView) view.findViewById(R.id.cv_pesanan);
        cvKonsultasi = (CardView) view.findViewById(R.id.cv_konsultasi);
        cvAdmin = (CardView) view.findViewById(R.id.cv_admin);

        cvBeli.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getContext(), WebActivity.class);
                intent.putExtra("link_tutorial", BuildConfig.tutorialBeli);
                intent.putExtra("nama_tutorial","Tutorial Beli Produk");
                startActivity(intent);
            }
        });

        cvPesanan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getContext(), WebActivity.class);
                intent.putExtra("link_tutorial",BuildConfig.tutorialPesanan);
                intent.putExtra("nama_tutorial","Tutorial Lihat Pesanan");
                startActivity(intent);
            }
        });

        cvKonsultasi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getContext(), WebActivity.class);
                intent.putExtra("link_tutorial",BuildConfig.tutorialRequest);
                intent.putExtra("nama_tutorial","Tutorial Konsultasi");
                startActivity(intent);
            }
        });

        cvAdmin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri uri = Uri.parse("https://api.whatsapp.com/send?phone=+6282371744445" + "&text=Saya butuh bantuan mengenai ...");
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(intent);
            }
        });

        return view;
    }

}
