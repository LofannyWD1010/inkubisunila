package com.sigerdev.inkubis;

import android.content.Context;
import android.content.SharedPreferences;

import com.sigerdev.inkubis.Model.Pengguna;

public class SharedPrefManager {
    private static final String SHARED_PREF_NAME = "FCMSharedPref";
    private static final String TAG_TOKEN = "tagtoken";
    private static final String KEY_ID = "key_id";
    private static final String KEY_NAMA = "key_nama";
    private static final String KEY_TELP = "key_telp";
    private static final String KEY_TOKEN = "key_token";
    private static final String KEY_FOTO = "key_foto";
    private static final String KEY_FIRST = "key_first";

    private static SharedPrefManager mInstance;
    private static Context mCtx;

    private SharedPrefManager(Context context) {
        mCtx = context;
    }

    public static synchronized SharedPrefManager getInstance(Context context) {
        if (mInstance == null) {
            mInstance = new SharedPrefManager(context);
        }
        return mInstance;
    }

    //this method will save the device token to shared preferences
    public boolean saveDeviceToken(String token){
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(TAG_TOKEN, token);
        editor.apply();
        return true;
    }

    //this method will fetch the device token from shared preferences
    public String getDeviceToken(){
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        return  sharedPreferences.getString(TAG_TOKEN, null);
    }

    public void userLogin(Pengguna pengguna) {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt(KEY_ID,pengguna.getIdPengguna());
        editor.putInt("key_saldo",pengguna.getSaldoPengguna());
        editor.putInt("key_status",pengguna.getStatusPengguna());
        editor.putString(KEY_NAMA, pengguna.getNamaPengguna());
        editor.putString(KEY_TELP, pengguna.getNoTelpPengguna());
        editor.putString(KEY_TOKEN, pengguna.getTokenPengguna());
        editor.putString("key_alamat", pengguna.getAlamatPengguna());
        editor.putString("key_daerah", pengguna.getDaerahPengguna());
        editor.putString(KEY_FOTO, pengguna.getFotoPengguna());
        editor.putString("key_email", pengguna.getEmailPengguna());
        editor.putString("key_password", pengguna.getPasswordPengguna());
        editor.putString("key_remember_token", pengguna.getRememberToken());
        editor.apply();
    }

    public boolean isLoggedIn() {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        return sharedPreferences.getString(KEY_NAMA, null) != null;
    }

    public void setFirst(){
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(KEY_FIRST, "FIRST");
        editor.apply();
    }

    public boolean isFirst() {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        return sharedPreferences.getString(KEY_FIRST, null) != null;
    }

    public Pengguna getPengguna() {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        return new Pengguna(
                sharedPreferences.getInt(KEY_ID, 0),
                sharedPreferences.getInt("key_saldo", 0),
                sharedPreferences.getInt("key_status", 0),
                sharedPreferences.getString(KEY_NAMA,null),
                sharedPreferences.getString(KEY_TELP,null),
                sharedPreferences.getString(KEY_TOKEN,null),
                sharedPreferences.getString("key_alamat",null),
                sharedPreferences.getString("key_daerah",null),
                sharedPreferences.getString(KEY_FOTO,null),
                sharedPreferences.getString("key_email",null),
                sharedPreferences.getString("key_password",null),
                sharedPreferences.getString("key_remember_token", null),
                sharedPreferences.getInt("key_status", 0)
        );
    }

    public void logout(){
        mCtx.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE).edit().clear().commit();
    }
}

