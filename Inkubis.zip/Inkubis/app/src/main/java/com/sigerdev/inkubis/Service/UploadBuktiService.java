package com.sigerdev.inkubis.Service;

import android.app.Service;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Environment;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.util.HashMap;
import java.util.Map;

import com.sigerdev.inkubis.BuildConfig;
import com.sigerdev.inkubis.SharedPrefManager;
import com.sigerdev.inkubis.VolleyMultipartRequest;

public class UploadBuktiService extends Service {

    Bitmap bmp;
    String kodePesanan, namaFoto;
    int idPengguna;

    public UploadBuktiService() {
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        kodePesanan = intent.getStringExtra("KODE_PESANAN");
        idPengguna = intent.getIntExtra("ID_PENGGUNA",0);
        namaFoto = intent.getStringExtra("NAMA_FOTO");

        bmp = null;
        String filename = Environment.getExternalStorageDirectory().getAbsolutePath() +  "/Pictures/" + namaFoto;
//        try {
//            FileInputStream is = new FileInputStream (new File(filename));
//            bmp = BitmapFactory.decodeStream(is);
//            is.close();
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
        bmp = BitmapFactory.decodeFile(filename);

        Log.d("SERVICEKU", namaFoto);

        VolleyMultipartRequest volleyMultipartRequest = new VolleyMultipartRequest(Request.Method.POST, BuildConfig.host + BuildConfig.ubahStatusPesan,
                new Response.Listener<NetworkResponse>() {
                    @Override
                    public void onResponse(NetworkResponse response) {
                        try {
                            JSONObject obj = new JSONObject(new String(response.data));

                            if(obj.getString("success").equalsIgnoreCase("Berhasil Ubah Status Pesanan")){
                                Toast.makeText(getApplicationContext(), obj.getString("success"), Toast.LENGTH_SHORT).show();
                            }else if(obj.getString("success").equalsIgnoreCase("Gagal Ubah Status Pesanan")){
                                Toast.makeText(getApplicationContext(), obj.getString("success"), Toast.LENGTH_SHORT).show();
                            }

                            stopSelf();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }) {

            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String>  params = new HashMap<String, String>();
                params.put("Authorization", "Bearer " + SharedPrefManager.getInstance(UploadBuktiService.this).getPengguna().getRememberToken());
                params.put("Accept", "application/json");

                return params;
            }

            /*
             * If you want to add more parameters with the image
             * you can do it here
             * here we have only one parameter with the image
             * which is tags
             * */
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();

                params.put("kode_pesanan", kodePesanan);
                params.put("id_pengguna", String.valueOf(idPengguna));

                return params;
            }

            /*
             * Here we are passing image by renaming it with a unique name
             * */
            @Override
            public Map<String, DataPart> getByteData() {
                Map<String, DataPart> params = new HashMap<>();
                params.put("foto", new DataPart("bukti.png", getFileDataFromDrawable(bmp)));
                return params;
            }
        };

        //adding the request to volley
        Volley.newRequestQueue(this).add(volleyMultipartRequest).setRetryPolicy(new DefaultRetryPolicy(0, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));


        stopSelf();

        return START_STICKY;
    }

    public byte[] getFileDataFromDrawable(Bitmap bitmap) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, byteArrayOutputStream);
//        long length =  byteArrayOutputStream.toByteArray().length;
//        length = length/1024;
//        Log.d("UKURAN", String.valueOf(length));
        return byteArrayOutputStream.toByteArray();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }


}
